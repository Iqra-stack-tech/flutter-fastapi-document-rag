import re
from qdrant_client import QdrantClient
from .config import (
    COLLECTION_NAME,
    KEYWORD_MATCH_THRESHOLD,
    KEYWORD_WEIGHT,
    MIN_SEMANTIC_SCORE,
    QDRANT_PATH,
    SEMANTIC_CANDIDATES,
    SEMANTIC_WEIGHT,
    TOP_K,
)
from .embedding_service import embedding_model

STOP_WORDS = {
    "a","an","and","are","as","at","be","been","by","does","for","from",
    "how","in","is","it","of","on","or","that","the","this","to","was",
    "what","when","where","which","who","why","with",
}

def tokenize(text: str) -> list[str]:
    words = re.findall(r"[a-zA-Z0-9]+", text.lower())
    return [word for word in words if word not in STOP_WORDS]

def keyword_score(query: str, document: str) -> float:
    query_words = set(tokenize(query))
    if not query_words:
        return 0.0

    document_words = set(tokenize(document))
    matches = query_words & document_words
    overlap_score = len(matches) / len(query_words)

    query_phrase = " ".join(tokenize(query))
    document_phrase = " ".join(tokenize(document))
    exact_score = 1.0 if query_phrase and query_phrase in document_phrase else 0.0

    return min(1.0, max(overlap_score, exact_score))

def _scroll_all_points(client: QdrantClient) -> list:
    points = []
    offset = None

    while True:
        batch, next_offset = client.scroll(
            collection_name=COLLECTION_NAME,
            limit=256,
            offset=offset,
            with_payload=True,
            with_vectors=False,
        )
        points.extend(batch)

        if next_offset is None:
            break
        offset = next_offset

    return points

def hybrid_retrieve(
    question: str,
    history: list[dict] | None = None,
    top_k: int = TOP_K,
) -> list[dict]:
    history = history or []
    recent_history = history[-4:]

    history_text = "\n".join(
        message.get("content", "")
        for message in recent_history
        if message.get("content")
    )

    semantic_query = (
        f"Conversation:\n{history_text}\n\nCurrent question:\n{question}"
        if history_text
        else question
    )

    query_embedding = embedding_model.encode(semantic_query)
    client = QdrantClient(path=str(QDRANT_PATH))

    try:
        if not client.collection_exists(COLLECTION_NAME):
            return []

        semantic_results = client.query_points(
            collection_name=COLLECTION_NAME,
            query=query_embedding.tolist(),
            limit=SEMANTIC_CANDIDATES,
            with_payload=True,
        ).points

        all_points = _scroll_all_points(client)
        candidates: dict = {}

        for result in semantic_results:
            candidates[result.id] = {
                "payload": result.payload or {},
                "semantic_score": max(0.0, float(result.score)),
            }

        for point in all_points:
            payload = point.payload or {}
            text = payload.get("text", "")
            lexical = keyword_score(question, text)

            if lexical > 0 and point.id not in candidates:
                candidates[point.id] = {
                    "payload": payload,
                    "semantic_score": 0.0,
                }

        ranked = []

        for point_id, candidate in candidates.items():
            payload = candidate["payload"]
            text = payload.get("text", "")
            semantic = float(candidate.get("semantic_score", 0.0))
            lexical = keyword_score(question, text)

            if semantic < MIN_SEMANTIC_SCORE and lexical < KEYWORD_MATCH_THRESHOLD:
                continue

            final_score = (
                SEMANTIC_WEIGHT * semantic
                + KEYWORD_WEIGHT * lexical
            )

            ranked.append({
                "id": point_id,
                "file": payload.get("source", "Unknown"),
                "page": int(payload.get("page", 0)),
                "chunk_id": int(payload.get("chunk_id", 0)),
                "text": text,
                "semantic_score": semantic,
                "keyword_score": lexical,
                "score": final_score,
            })

        ranked.sort(key=lambda item: item["score"], reverse=True)
        return ranked[:top_k]
    finally:
        client.close()
