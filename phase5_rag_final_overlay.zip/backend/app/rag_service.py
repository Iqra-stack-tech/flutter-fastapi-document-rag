import os
from dotenv import load_dotenv
from openai import OpenAI
from .config import BACKEND_DIR, GROQ_MODEL
from .retrieval import hybrid_retrieve

load_dotenv(dotenv_path=BACKEND_DIR / ".env")

groq_api_key = os.getenv("GROQ_API_KEY")
if not groq_api_key:
    raise ValueError("GROQ_API_KEY was not found in backend/.env")

llm_client = OpenAI(
    api_key=groq_api_key,
    base_url="https://api.groq.com/openai/v1",
)

REFUSAL = (
    "The provided documents do not contain enough information "
    "to answer this question."
)

def ask_document(
    question: str,
    history: list[dict] | None = None,
) -> dict:
    history = history or []
    recent_history = history[-4:]

    retrieved = hybrid_retrieve(
        question=question,
        history=recent_history,
    )

    if not retrieved:
        return {"answer": REFUSAL, "sources": []}

    context_parts = []
    for item in retrieved:
        context_parts.append(
            f'[SOURCE: {item["file"]} | PAGE: {item["page"]} | CHUNK: {item["chunk_id"]}]\n'
            f'{item["text"]}'
        )

    context = "\n\n".join(context_parts)

    user_prompt = f"""
Answer the current question using only the information explicitly
supported by the DOCUMENT CONTEXT below.

Do not use outside knowledge.
Do not invent examples, names, definitions, or facts.

Conversation history may only help you understand references such as
"it", "that", "why", or "the previous point".

Cite factual claims using:
[Source: filename, Page: number]

If the document context is insufficient, respond exactly:
"{REFUSAL}"

DOCUMENT CONTEXT:
{context}

CURRENT QUESTION:
{question}
"""

    messages = [{
        "role": "system",
        "content": (
            "You are a document-grounded question-answering assistant. "
            "Use only retrieved document evidence for factual answers."
        ),
    }]

    for message in recent_history:
        role = message.get("role")
        content = message.get("content")
        if role in {"user", "assistant"} and content:
            messages.append({"role": role, "content": content})

    messages.append({"role": "user", "content": user_prompt})

    response = llm_client.chat.completions.create(
        model=GROQ_MODEL,
        messages=messages,
        temperature=0.2,
        max_tokens=500,
    )

    answer = (
        response.choices[0].message.content
        or REFUSAL
    ).strip()

    if answer == REFUSAL:
        return {"answer": answer, "sources": []}

    sources = [{
        "file": item["file"],
        "page": item["page"],
        "chunk_id": item["chunk_id"],
        "score": round(item["score"], 4),
        "semantic_score": round(item["semantic_score"], 4),
        "keyword_score": round(item["keyword_score"], 4),
    } for item in retrieved]

    return {"answer": answer, "sources": sources}
